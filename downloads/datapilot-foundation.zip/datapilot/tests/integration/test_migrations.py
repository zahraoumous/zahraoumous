"""Run only against an empty disposable database: applies, reverses and reapplies DDL."""

import os
import subprocess
import sys
from uuid import uuid4

import pytest
from alembic.autogenerate import compare_metadata
from alembic.migration import MigrationContext
from app.models import Base
from sqlalchemy import create_engine, inspect, text
from sqlalchemy.exc import IntegrityError

pytestmark = pytest.mark.integration


def test_schema_and_tenant_foreign_keys():
    url = os.environ.get("DATAPILOT_TEST_DATABASE_URL")
    if not url:
        pytest.skip("DATAPILOT_TEST_DATABASE_URL must name an empty disposable database")
    environment = {**os.environ, "DATAPILOT_DATABASE_URL": url}
    engine = create_engine(url)
    try:
        assert not inspect(engine).get_table_names(), "Refusing to migrate a nonempty test database"

        def migrate(target):
            subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "alembic",
                    "upgrade" if target == "head" else "downgrade",
                    target,
                ],
                env=environment,
                check=True,
            )

        migrate("head")
        with engine.connect() as connection:
            differences = compare_metadata(MigrationContext.configure(connection), Base.metadata)
            assert differences == [], differences
        org_a, org_b, user, dataset = [uuid4() for _ in range(4)]
        with engine.begin() as connection:
            connection.execute(
                text("INSERT INTO organizations (id,name) VALUES (:a,'A'),(:b,'B')"),
                {"a": org_a, "b": org_b},
            )
            connection.execute(
                text("INSERT INTO users (id,oidc_sub,email) VALUES (:u,'sub','a@example.test')"),
                {"u": user},
            )
            connection.execute(
                text(
                    "INSERT INTO datasets (id,organization_id,created_by,name,"
                    "source_type) VALUES (:d,:o,:u,'sample','csv')"
                ),
                {"d": dataset, "o": org_a, "u": user},
            )
        with pytest.raises(IntegrityError):
            with engine.begin() as connection:
                connection.execute(
                    text(
                        "INSERT INTO dataset_versions (organization_id,dataset_id,"
                        "version_number,raw_object_key,source_sha256) VALUES (:o,:d,1,'raw',:hash)"
                    ),
                    {"o": org_b, "d": dataset, "hash": "a" * 64},
                )
        with pytest.raises(IntegrityError):
            with engine.begin() as connection:
                connection.execute(
                    text(
                        "INSERT INTO memberships (organization_id,user_id,"
                        "role) VALUES (:o,:u,'admin')"
                    ),
                    {"o": org_a, "u": user},
                )
        migrate("base")
        assert set(inspect(engine).get_table_names()) == {"alembic_version"}
        migrate("head")
        assert len(inspect(engine).get_table_names()) == len(Base.metadata.tables) + 1
    finally:
        engine.dispose()
