import Link from "next/link";

export default function Home() {
  return <main><span className="eyebrow">DATAPILOT AI · DEVELOPMENT FOUNDATION</span>
    <h1>Understand your data.<br /><em>Trust every insight.</em></h1>
    <p>A workspace for spreadsheet quality, transparent analytics, and evidence-backed reports.</p>
    <Link className="button" href="/app">Open workspace →</Link>
    <section aria-label="Delivery status" className="grid">
      <article><span>01 / FOUNDATION</span><h2>A clear starting point</h2><p>Typed API health checks, PostgreSQL metadata, and a local service stack.</p></article>
      <article><span>02 / NEXT</span><h2>Secure access</h2><p>OIDC authentication and organization authorization must be implemented before customer data.</p></article>
      <article><span>03 / PLANNED</span><h2>Evidence first</h2><p>Immutable datasets, approved cleaning, and reproducible analytics are planned.</p></article>
    </section>
  </main>;
}
