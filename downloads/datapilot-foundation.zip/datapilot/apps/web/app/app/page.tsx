import Link from "next/link";

export default function Workspace() {
  return <main><Link href="/">← DataPilot AI</Link><h1>Your workspace</h1>
    <section><span className="eyebrow">NO DATASETS YET</span><h2>Start with a secure foundation</h2>
    <p>Uploads and analysis are not available in this foundation release. No customer data is stored through this interface.</p>
    <p>Next milestone: OIDC login and organization-scoped access.</p></section>
  </main>;
}
