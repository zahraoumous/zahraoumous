"""Check every screen route against the route contract (running web required)."""
import sys
import urllib.request

base = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:3000"
routes = {
    "/": "Your data workspace",
    "/sign-in": "Sign in to your workspace",
    "/app": "Your data workspace",
    "/app/datasets/new": "Bring your data together",
    "/app/datasets/demo": "Sales dataset",
    "/app/datasets/demo/quality": "Understand your data quality",
    "/app/datasets/demo/clean": "Review before you clean",
    "/app/datasets/demo/analyze": "What would you like to understand?",
    "/app/analyses/demo": "Sales overview",
    "/app/analyses/demo/insights": "The story behind the numbers",
    "/app/dashboards/demo": "Your sales dashboard",
    "/app/datasets/demo/ask": "Ask a better question",
    "/app/analyses/demo/export": "Share your findings",
}
for route, title in routes.items():
    with urllib.request.urlopen(base + route, timeout=20) as response:
        html = response.read().decode()
        assert response.status == 200, route
        assert title in html, (route, title)
        if route not in ("/sign-in",):
            assert "UI PREVIEW" in html, route
    print("PASS", route)
print("All 12 screen routes and the root redirect passed.")
