from app.core.config import get_settings
from celery import Celery

settings = get_settings()
celery_app = Celery("datapilot", broker=settings.redis_url.get_secret_value())
celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    broker_connection_retry_on_startup=True,
    task_time_limit=120,
    task_soft_time_limit=110,
    worker_prefetch_multiplier=1,
)


@celery_app.task(name="datapilot.ping")
def ping() -> dict[str, str]:
    """Infrastructure probe only. No upload parsing or analysis execution."""
    return {"status": "ok"}
