# DataPilot AI — runnable foundation

Generated from the supplied DataPilot build package. This implements the selected foundation scope, not the six-week MVP. The original profile README at the repository root is unchanged.

## Included

- Next.js/React/TypeScript preview of all 12 specified screens, with sidebar navigation and selectable loading, empty, processing, error and denied states. The root route opens the workspace.
- FastAPI `/health/live` and `/health/ready`, typed responses and request IDs.
- All 16 metadata tables mapped with SQLAlchemy; a frozen Alembic baseline equivalent to the supplied PostgreSQL DDL, including composite tenant foreign keys, constraints and indexes.
- PostgreSQL, Redis, MinIO, API, migration, Celery infrastructure worker and web in Docker Compose.
- Exact direct dependency pins, `uv.lock`, `package-lock.json`, generated API TypeScript types, tests and a repository-root GitHub Actions workflow.

OIDC, organization authorization, ingestion, isolated analysis, cleaning, dashboards, AI, PDF and Power BI are future milestones. Business API routes are deliberately absent until authentication and tenant checks exist. The UI uses an explicitly labeled three-row illustrative fixture. The sample totals are reproducible from those rows and do not represent uploaded data. The worker only provides an infrastructure ping; it cannot process customer uploads. The sandbox is not implemented and no Docker socket is mounted.

## Start locally

Requirements: Docker Engine with Compose v2/BuildKit, at least 4 GB available RAM and roughly 8 GB disk for initial builds. Python 3.12, uv 0.12.23 and Node 24/npm are needed only for host development/testing.

From this directory (`datapilot/`):

```sh
cp -n .env.example .env
# Review .env. Its public sample credentials are local-development-only.
sh scripts/dev.sh
python3 scripts/smoke.py
docker compose --env-file .env -f infra/docker-compose.yml exec -T worker celery -A worker.celery_app inspect ping --timeout=5
```

The MinIO image uses official upstream release binaries with pinned SHA-256 values for Linux amd64 and arm64. Only amd64 was exercised here. The official `minio/minio` image could not be pulled, so the Dockerfile assembles the local image from verified release assets. MinIO is AGPL-3.0: see `third_party/README.md` and the included upstream license before redistribution or deployment. This stack is for local development, not production.

Compose binds only web and API ports to host loopback. Readiness checks query migrated PostgreSQL, ping Redis and authenticate to S3 to list buckets. Readiness does not claim a configured upload bucket or completed business features. The web shell has no API-dependent business UI yet.

If HTTPS inspection requires a trusted CA, set `DATAPILOT_BUILD_CA_FILE` to an approved PEM bundle before `scripts/dev.sh`. It enables `infra/docker-compose.ca.yml`, mounting the bundle for build steps only. TLS and checksum verification remain enabled. Do not use insecure registry or TLS bypass options.

Stop with `docker compose --env-file .env -f infra/docker-compose.yml down`. Named volumes preserve local data. Do not add `-v` unless deliberately deleting it.

## Develop and check

```sh
uv sync --frozen
npm ci
uv run ruff check .
uv run ruff format --check .
uv run mypy
uv run pytest -m 'not integration'
npm run build
npm run typecheck
npm audit --omit=dev --audit-level=high
uvx pip-audit==2.10.1 --path .venv/lib/python3.12/site-packages --progress-spinner off
```

Use `UV_CACHE_DIR`, `npm_config_cache` and `BUILDX_CONFIG` pointing under `/tmp` if the cloud user's home is read-only. For example `UV_CACHE_DIR=/tmp/datapilot-uv uv sync --frozen`.

Run the integration test only against a **new, empty, disposable PostgreSQL database**:

```sh
export DATAPILOT_TEST_DATABASE_URL='postgresql+psycopg://USER:PASSWORD@HOST:5432/datapilot_test'
uv run pytest -m integration
```

It refuses a nonempty database, applies the migration, compares the ORM metadata, tests cross-tenant version references and invalid roles, downgrades and reapplies the migration. It leaves the disposable database migrated. Without the test URL the test is explicitly skipped. CI supplies a disposable PostgreSQL service.

## API contract

```sh
PYTHONPATH=services/api uv run python scripts/export_openapi.py
npm run api:types
```

Commit the generated `packages/api-contract/openapi.json` and `index.d.ts`. They describe **implemented health endpoints only**. `docs/specification/openapi.yaml` remains the unchanged proposed business API contract; it is not a claim of implemented routes. CI checks that generated outputs match the application.

## Layout

```text
apps/web/                 Next.js shell
services/api/app/         FastAPI, settings and SQLAlchemy entities
services/api/alembic/     Immutable initial DDL and migration
services/worker/          Celery infrastructure task
packages/api-contract/    Generated OpenAPI and TypeScript definitions
infra/                    Compose stack and Dockerfiles
scripts/                  Startup, smoke test and contract generation
tests/                    Health and real PostgreSQL migration tests
docs/specification/       All five original supplied files, unchanged
```

See [validation](docs/VALIDATION.md) for checks actually run, and [next steps](docs/NEXT_STEPS.md) for the remaining milestones. No PR, commit, publication or deployment has been performed automatically.
