# Validation evidence

Validated in the cloud workspace on 2026-10-27 (Linux amd64).

## Passed

- Frozen Python dependency installation and clean `npm ci` through `scripts/cloud-install.sh`.
- Next.js 16.4.3 production build and TypeScript check.
- Ruff lint and formatting checks; mypy across API/worker sources.
- Five existing tests passed in a full run: four HTTP health/error tests and one real PostgreSQL integration test. The four health tests were rerun after the S3 client cleanup fix and passed again.
- Integration test: initial migration, SQLAlchemy schema comparison, invalid-role rejection, cross-organization dataset-version FK rejection, downgrade and re-upgrade against disposable PostgreSQL databases.
- Docker builds of API/worker, web and a checksum-verified official MinIO amd64 release binary.
- The documented `scripts/dev.sh` completed successfully with the cloud build CA bundle. Migration was also reapplied safely to the existing development database during successive startups.
- `python scripts/smoke.py`: both web routes returned expected content; API liveness returned 200; readiness returned 200 with PostgreSQL, Redis and object storage all true.
- Celery `inspect ping`: one worker responded `pong`.
- npm production dependency audit: zero reported vulnerabilities.
- pip-audit 2.10.1 over installed Python packages: no known vulnerabilities reported.
- All five original build-package files preserved byte-for-byte under `docs/specification/`; existing repository-root profile README unchanged.

## Corrections included

- Upgraded Next.js, pydantic-settings and pytest after dependency audit findings, then regenerated locks and reran affected checks.
- Added optional build-only trusted-CA mounts for this cloud's HTTPS inspection; no TLS or checksum verification was disabled.
- Set copied source ownership for non-root containers, and used explicit S3 client cleanup.
- Added Compose `NO_PROXY` entries for internal PostgreSQL, Redis and MinIO traffic.
- Used verified official MinIO release assets after its container image was unavailable. A source-build attempt was blocked by a Go dependency redirect to a denied domain; the final binary-based build needs no such domain. The temporary draft domain addition was removed.

## Limits

No OIDC, resource-level tenant authorization, upload/analysis features, sandbox, Power BI template, or full user workflow is implemented. Composite database foreign keys are not application authorization. No production deployment, container vulnerability scan, manual browser/accessibility check, arm64 runtime test, GitHub-hosted CI run, cloud publication or restoration in a fresh task was performed. The GitHub workflow is generated for execution after committing/pushing; equivalent applicable local checks were run here. A dependency audit is a point-in-time package scan, not a security certification.

The test runner emitted an upstream Starlette/httpx deprecation warning; tests passed. No test was disabled to resolve a failure. Integration tests require a disposable database and otherwise report an explicit skip.

## Cloud configuration

`install_script` and `start_skill` were saved in the environment draft. They reproduce dependency setup and restart/verify the local service stack. No credentials or expanded network access are required by the final implementation. Review and save the configuration in environment settings, then publish to make the prepared environment reusable. Draft saving does not publish it, and live containers are not assumed to survive restoration.

## UI preview update

The frontend now provides all 12 routes in the supplied architecture, including sign-in, with a sidebar linking the 11 workspace screens. The root redirects to the workspace. Dataset preview, quality, cleaning approval, analysis setup/results, insights, dashboard, Q&A and export screens use an explicitly labeled three-row fixture. Workspace screens include selectable completed/loading/empty/processing/error/access-denied states. File selection remains local; approval and questions are UI previews, not backend operations.

The updated production build and TypeScript check pass. `scripts/check-wireframes.py` checks all 12 screen routes plus the root redirect for HTTP 200, expected screen text and preview labeling. No automated browser interaction or visual comparison with external design images was performed; the source package contains textual screen contracts rather than wireframe image assets.
