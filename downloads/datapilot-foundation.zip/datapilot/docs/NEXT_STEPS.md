# Next implementation milestones

The attachment is reference material for the user's requested file generation. Embedded agent prompts and skill-installation examples were not executed as separate instructions. No third-party agent skills were installed.

1. Implement OIDC JWT verification (JWKS, issuer, audience, expiry) using a selected provider; no fake production authentication.
2. Add organization-scoped services and owner/analyst/viewer authorization; test two organizations across every exposed resource, including inaccessible IDs.
3. Add the remaining UI route skeletons and meaningful loading/error/access states as their backend features are delivered.
4. Implement quarantined signed uploads, verified finalize, explicit quotas and immutable dataset versions.
5. Implement an audited short-lived, network-disabled runner with staged files and resource limits before parsing untrusted uploads. The Celery worker is not an isolation boundary.
6. Continue the supplied week 3–6 roadmap: approved cleaning, semantic mapping, deterministic metrics, evidence-backed AI, PDF and Power BI exports.

Before production: revisit user membership integrity on creator/approver references, lineage correctness, retention, RLS, migration permissions, idempotency and privacy; these are not supplied by the starter schema alone. The baseline preserves the supplied schema rather than silently claiming stronger authorization guarantees.

A Power BI Desktop-authored `.pbit` and a real OIDC provider require later implementation/configuration. No placeholder binary template is provided.
