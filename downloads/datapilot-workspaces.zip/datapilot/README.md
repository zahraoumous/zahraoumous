# DataPilot — workspaces and real file processing

This release implements local accounts, persistent workspaces, multi-file/folder imports, background CSV/XLSX ingestion, dataset previews and deterministic quality findings. It replaces the earlier UI-only prototype. Cleaning, business analytics, AI answers and exports remain explicitly unavailable; there are no fabricated execution results.

## Update and start

Docker Engine/Compose v2 on Linux is required for the isolated parser. Allow at least 4 GB RAM and 10 GB free disk for builds, application images and local data. From `datapilot/`:

```sh
# First install only: copy .env.example to .env, then review its local credentials.
# When updating, keep your existing .env and named Docker volumes.
sh scripts/dev.sh
```

`dev.sh` builds the services, applies Alembic migrations, starts the worker and waits for API readiness. The development database and objects survive container rebuilds. Do not run `down -v` when updating: it deletes local data. If HTTPS inspection requires a trusted CA, set `DATAPILOT_BUILD_CA_FILE` to its PEM bundle before startup. Verification stays enabled.

The browser uses port 3000; the root opens the workspace. You do not need to install Python or Node on your own machine when using Docker.

![DataPilot import workbench](docs/screenshots/import-manifest.png)

## Your first real execution

1. Open the app and choose **Sign in or create an account**. On the account page select **Create account**. Use your email, name and a password of at least 12 characters. There are no default accounts.
2. Give your first workspace a name and choose **Create workspace**. Workspace data is visible only to its members; a new workspace makes you its owner.
3. Open **Import sources**. Choose multiple CSV/XLSX files, or **Choose folder** to select a folder and its supported files, including nested paths. Unsupported files are shown as excluded. Check the manifest and remove anything you do not want to import.
4. Start the import. Browser upload progress is followed by persisted per-file processing states. Open **Executions** to see queued/running/completed/failed jobs. A malformed file can fail while the other files complete. Retry affects failed files only.
5. Open a completed source to see real row/column counts, the first 100 rows, inferred schema, missing values, quality findings, original relative path and source checksum. Reloading or signing in again restores your workspaces and results.

The folder picker is browser-dependent; multiple-file selection is the fallback. Selecting a folder imports the files once; it does not create a filesystem watcher or a live database connection. Folder hierarchy is metadata, not a path used to write files on the server. Files are imported as independent datasets, not silently joined.

## Supported files and limits

- CSV and XLSX only. Up to 100 files, 25 MiB per file, 100 MiB per import.
- At most 250,000 rows and 50 columns per dataset. Preview is limited to 100 rows.
- XLSX uses the first visible worksheet. Other worksheets require a separate file; formulas/macros are not executed. Formula-containing workbooks and suspicious/malformed ZIP containers fail with a visible reason.
- Quality checks cover missing values, exact duplicate rows, mixed numeric/text columns and formula-like text. Findings do not modify the original source.
- Original bytes and SHA-256 are preserved; canonical Parquet and metadata are saved. Numeric type inference preserves leading-zero identifiers rather than guessing business meaning.

## Architecture and isolation

Next.js proxies same-origin API requests to FastAPI; HttpOnly SameSite cookies hold opaque sessions whose hashes are stored in PostgreSQL. Passwords use parameterized scrypt with random salts. Session expiry/logout, request-origin checks, login throttling and workspace membership are enforced server-side.

PostgreSQL is authoritative for jobs. One Celery worker with beat dispatches durable queued imports every five seconds; interrupted jobs become retryable failures instead of remaining running indefinitely. Redis carries messages. MinIO stores original files and Parquet.

Every file is parsed in a short-lived bounded subprocess with a scrubbed environment and seccomp network/process restrictions. The Docker worker orchestrator has only the capabilities needed to construct a chroot and drop the parser to a separate non-root UID; its per-job root contains trusted runtime files and that job's staged data. No host or Docker socket is mounted. A kernel Landlock path is also supported for compatible non-root environments; if no supported filesystem boundary can be applied, parsing fails closed. CPU, memory, output and wall-time limits apply. See `docs/SECURITY.md` for deployment limits.

All service ports exposed to the host bind to loopback. The worker requires the explicit capabilities in Compose; removing them without supplying a supported replacement sandbox will make jobs fail. Do not enable privileged mode to work around failures.

## Development and checks

Host development requires Python 3.12, uv 0.12.23 and Node 24:

```sh
sh scripts/cloud-install.sh
uv run ruff check .
uv run ruff format --check .
uv run mypy
uv run pytest -m 'not integration'
npm run build
npm run typecheck
```

Integration tests require two different empty disposable PostgreSQL databases, set through `DATAPILOT_TEST_DATABASE_URL` and `DATAPILOT_FLOW_DATABASE_URL`. Tests refuse nonempty databases. The former tests migration upgrade/downgrade/re-upgrade; the latter tests authentication, authorization, paths, limits and rollback with in-memory object storage. Real storage/worker execution is tested separately:

```sh
python3 scripts/smoke.py
python3 scripts/real-flow-smoke.py
node scripts/browser-smoke.mjs
```

The real-flow/browser checks create their own randomly named validation accounts and workspaces. They never log credentials. Browser checks need Chromium (`CHROMIUM_PATH` can select an executable), or Playwright's installed browser. See `docs/VALIDATION.md` for outcomes actually verified.

If the cloud home is read-only, set `UV_CACHE_DIR=/tmp/datapilot-uv`, `npm_config_cache=/tmp/datapilot-npm` and `BUILDX_CONFIG=/tmp/datapilot-buildx`. The cloud install helper already sets its package cache locations.

## API contract

```sh
PYTHONPATH=services/api uv run python scripts/export_openapi.py
npm run api:types
```

Frontend response types use `packages/api-contract/index.d.ts`, generated from implemented FastAPI endpoints. `docs/specification/` preserves all five original design files unchanged; its six-week plan and proposed OpenAPI are reference material, not a claim that every feature is implemented.

## Repository layout

- `apps/web/`: account screens, workspace/import UI and same-origin API proxy.
- `services/api/app/features/`: accounts, sessions, membership, imports and dataset API.
- `services/api/app/processing/`: deterministic parser, jail, kernel restrictions and launcher.
- `services/worker/`: durable job dispatch and ingestion orchestration.
- `services/api/alembic/`: immutable initial schema plus additive workspace/account migration.
- `infra/`: Compose and API/web/MinIO Dockerfiles.
- `tests/` and `scripts/`: API, migration, parser and live/browser checks.

The official MinIO amd64/arm64 binaries are checked against pinned upstream SHA-256 values. Only amd64 runtime was tested here. MinIO's AGPL license and provenance are in `third_party/`. Review license obligations before deployment or redistribution.
