# Next increments

The current release delivers real accounts, workspaces, multi-file/folder imports, bounded CSV/XLSX ingestion, immutable source files, previews and quality findings. The following remain separate increments:

1. Controlled cleaning previews and explicitly approved immutable cleaned versions.
2. User-confirmed semantic mapping and deterministic business metrics with golden numerical tests.
3. Evidence-backed analysis/dashboard routes and an optional structured-output AI planner.
4. Fixed report/PDF exports and the Power BI handoff package/template.
5. Managed OIDC, account recovery/verification, team administration and broader production hardening.
6. Automated retention, historical storage quotas, orphan/session cleanup, backups and restoration drills.

Folders currently import supported files once. Watching folders, merging files, joining arbitrary datasets, live database connectors and arbitrary code/SQL execution are not implemented.
