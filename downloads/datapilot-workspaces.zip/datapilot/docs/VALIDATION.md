# Validation evidence — real workspace/import release

Validated on 2026-10-27 using Linux amd64 and the supplied Docker Compose topology.

## Passed

- Full automated suite: **33 tests passed**, none skipped in the configured run, using two disposable PostgreSQL databases. This includes migration upgrade/downgrade/re-upgrade and ORM comparison; account/session/CSRF/workspace access checks; limits, upload rollback and path handling; parser fixtures; and streaming body-limit checks.
- Parser tests were rerun after correcting extensionless XLSX staging; all 11 parser cases passed. Original input bytes are preserved.
- Ruff lint/format checks and mypy over all 22 API/worker source modules passed.
- Next.js production builds and TypeScript checks passed.
- Docker API, worker, web and MinIO startup passed. Alembic migration `0002` applies additively to the previous foundation schema.
- Direct sandbox probe: network denied, outside filesystem inaccessible, parser non-root, credential environment absent — all true. Bounded CSV parsing produced the expected Parquet, row counts and source SHA-256.
- Real HTTP workflow: registration/login/logout; workspace creation; a batch containing CSV, valid XLSX and malformed XLSX; queued/running/terminal states; preserved nested source paths; exact row/column counts, hashes and previews; null and duplicate findings; successful subsequent import; and cross-account denial for workspace/import/dataset/retry endpoints. The malformed file failed while valid files succeeded.
- Real Chromium browser workflow: account creation, workspace creation, folder selection including nested CSV files, visible exclusion of an unsupported text file, actual processing, preview/schema, reload persistence, HttpOnly SameSite session cookie, responsive390px overview without document overflow, sign-out and sign-in restoring the workspace. No browser page errors were reported.
- Runtime npm dependency audit: zero reported vulnerabilities. pip-audit2.10.1 over installed Python packages: no known vulnerabilities reported. These are point-in-time package audits, not container/production certification.
- Both web routes and readiness checks passed; readiness queries migrated PostgreSQL, Redis and authenticated MinIO access. Screen-shell HTTP checks passed separately; they do not stand in for authenticated functional checks.
- The final GitHub ZIP is downloaded and byte-checked during publication. Original supplied specification files and the repository-root profile README are preserved.

## Corrections found by real execution checks

The browser/API checks were allowed to fail and used to diagnose actual issues. The worker's limited capabilities required setting file mode before changing ownership; this ordering is corrected without granting additional parser privileges. Staged XLSX originals intentionally have no extension, so openpyxl now reads a bounded binary stream. Mobile table labels are contained by their scroll wrapper, preserving table scrolling without expanding the document. Mobile sign-out is available in the topbar.

Repeated image builds exhausted this cloud machine's disk. Only unused build cache and dangling images were removed; named data volumes were retained. Services were recovered and the live checks were rerun successfully. Live checks create randomly named validation accounts/workspaces and never print their credentials. They do not delete user work.

Screenshots from actual browser executions are included in `docs/screenshots/`.

## Not claimed

OIDC, email verification/password recovery, invitations/admin tooling, cleaning, business-semantic analytics, AI answers, PDF/Power BI exports, watched folders, automatic file joins and production deployment are not implemented. Remaining screens state their availability honestly. No production container scan, backup/restore drill, arm64 runtime check, GitHub-hosted CI run or fresh-task cloud restoration was performed. The generated CI workflow contains the relevant checks for when the application source is committed.

The test runner emits an upstream Starlette/httpx deprecation warning; tests still execute and pass. Integration tests explicitly skip if their disposable database URLs are absent; the full validation run supplied both databases and did not skip them.

## Reuse

Install/start instructions are saved in the cloud configuration draft. Review and save them in environment settings, then publish to reuse the prepared cloud environment. Saving a draft does not publish a snapshot, and running processes must restart after restoration. Local Docker users can start directly with `scripts/dev.sh` or the documented Compose command.
